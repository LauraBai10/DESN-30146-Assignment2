class Particle {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.angle = random(360);
        this.vx = random(-2, 2);
        this.vy = random(-5, -1);
        this.d = random(32, 128) / 1.5;
    }

    finished() {
        return this.d < 0;
    }

    update() {
        this.x += this.vx;
        this.y += this.vy;
        this.d -= 1 / 2;
    }

    show() {
        push();
        translate(this.x, this.y);
        image(g, 0, 0, this.d, this.d);
        pop();
    }
}