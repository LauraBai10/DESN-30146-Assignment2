let video;
let pose;
//let img1;
//let img2;
let skeleton;
let angle = 0;

function setup() {
    //createCanvas(400, 300); 
    b = new Ball();
    //pn = new PNet();

    createCanvas(640, 480);
    noStroke();
    video = createCapture(VIDEO);
    video.size(width, height);

    poseNet = ml5.poseNet(video, modelLoaded);
    poseNet.on('pose', gotPoses)
    //img1 = loadImage('images/hand2.svg');
    //img2 = loadImage('images/face.svg');    
    video.hide();

    rectMode(CENTER);
    angleMode(DEGREES);


}

function modelLoaded() {
    console.log("modelLoaded function has been called so this work!!!!");
};

function preload() {
    head = loadImage('images/head.png');
    nose = loadImage('images/Nose1.png');
    leftEye = loadImage('images/leftEye.png');
    rightEye = loadImage('images/rightEye.png');
    mouse = loadImage('images/Mouse.png');
}


function gotPoses(poses) {

    if (poses.length > 0) {
        pose = poses[0].pose;
        skeleton = poses[0].skeleton;
        // print(pose);
    }
}


function draw() {


    image(video, 0, 0, width, height);
    //TRESHOLD 0 is white  1 is black
    filter(THRESHOLD, 1);

    if (pose) {

        let NosePos = pose.nose;
        let leftEyePos = pose.leftEye;
        let rightEyePos = pose.rightEye;


        let d = dist(pose.leftEye.x, pose.leftEye.y, pose.rightEye.x, pose.rightEye.y);
        // print(d);
        let scale = map(d, 0, 90, 0, 1);

        for (let i = 0; i < pose.keypoints.length; i++) {

            let x = pose.keypoints[i].position.x;
            let y = pose.keypoints[i].position.y;

            push();
            fill(255);
            circle(x, y, 25);
            pop();

            push();
            for (let i = 0; i < skeleton.length; i++) {
                let a = skeleton[i][0];
                let b = skeleton[i][1];
                strokeWeight(5);
                stroke(255);
                line(a.position.x, a.position.y, b.position.x, b.position.y);
                fill(127);
            }
            pop();
        }

        push();
        imageMode(CENTER);
        push();
        //head
        let headScale = head.width / head.height;
        let headPicHeight = head.height * scale
        let headPicWidth = headPicHeight * headScale;
        let rotateAngle = Math.atan2(leftEyePos.y - rightEyePos.y, leftEyePos.x - rightEyePos.x) * (180 / Math.PI);
        print(rotateAngle);
        translate(NosePos.x, NosePos.y);
        rotate(rotateAngle);
        image(head, 0, - headPicHeight / 6, headPicWidth, headPicHeight);

        //nose
        let noseScale = nose.width / nose.height;
        let nosePicHeight = nose.height * scale
        let nosePicWidth = nosePicHeight * noseScale;
        image(nose, 0, 0, nosePicWidth, nosePicHeight);

        //mouse
        let mouseScale = mouse.width / mouse.height;
        let mousePicHeight = mouse.height * scale
        let mousePicWidth = mousePicHeight * mouseScale;
        image(mouse, headPicHeight / 25, headPicHeight / 8, mousePicWidth, mousePicHeight);
        pop();

        //leftEye
        let leftEyeScale = leftEye.width / leftEye.height;
        let leftEyePicHeight = leftEye.height * scale
        let leftEyePicWidth = leftEyePicHeight * leftEyeScale;
        image(leftEye, leftEyePos.x, leftEyePos.y, leftEyePicWidth, leftEyePicHeight);

        //rightEye
        let rightEyeScale = rightEye.width / rightEye.height;
        let rightEyePicHeight = rightEye.height * scale
        let rightEyePicWidth = rightEyePicHeight * rightEyeScale;
        image(rightEye, rightEyePos.x, rightEyePos.y, rightEyePicWidth, rightEyePicHeight);

        pop();



    }
}